Dragon Chess Maze - Optimization Capstone
Developed by: Shyam Parikh & Samuel Boncik

Project Type: AI-Integrated Strategy Game (Pygame & Numba JIT)

Project Overview
Dragon Chess Maze is a high-performance chess engine and mini-game built in Python. The project focuses on the intersection of complex game logic (AI move calculation) and performance optimization. It features a custom AI opponent ("The Dragon") and a visual testing arena that measures real-time performance metrics.

Key Optimizations (Option C Requirements)
Single-Access JIT Indexing: - Located in optimized_game_module.py.

Optimized from Multi-Access to Single-Access indexing. By indexing a data point once and storing it rather than re-indexing multiple times, we minimized redundant system resource calls.

Result: A 1.12% increase in speed, which significantly reduces processing time when generating hundreds of thousands of moves.

Numba JIT Compilation:

Uses the @njit decorator to compile heavy mathematical evaluation functions (like mop_up_eval) into machine code for near-instant calculations.

Multithreaded AI Thinking: - Located in the game game - v8 source files.

Move calculations are offloaded to a background thread. This ensures the Pygame window remains responsive and maintains a consistent 60 FPS while "The Dragon" calculates its next move.

KPIs (Performance Metrics)
Stress Test Latency: Measured using a script to generate 10,000,000 dummy moves.

Pre-Optimization: 0.00271s

Post-Optimization: 0.00268s

Time Efficiency: Demonstrated a reduction of 9 seconds of processing time for every 13 minutes of heavy computation.

How to Run
Prerequisites: Ensure you have Python 3.10+ and the required libraries:
pip install pygame numba numpy

Execution: Navigate into the game 'game - v8' folder and run the main script:
python main.py

Folder Structure
/next_unit_option_C/

/game - v8/ (Contains all core game files)

optimized_game_module.py (Engine & Single-Access JIT Logic)

Performance_Report.pdf (Includes the 10M move stress test results)

Do_Nows_Exit_Tickets.docx (Class 1-6 Plan)

/game - v8/images/ (Required graphical assets for pieces and board)